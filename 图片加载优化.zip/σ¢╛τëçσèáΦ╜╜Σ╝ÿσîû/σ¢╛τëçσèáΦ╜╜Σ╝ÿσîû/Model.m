//
//  Model.m
//  图片加载优化
//
//  Created by 张超 on 16/9/7.
//  Copyright © 2016年 张超. All rights reserved.
//

#import "Model.h"

@implementation Model
+ (NSDictionary *)objectClassInArray{
    return @{@"results" : [Result class]};
}

@end
@implementation Result



@end
